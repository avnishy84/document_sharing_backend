module.exports = {
    secret: "LoginSecretKey"
  };